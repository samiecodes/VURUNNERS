/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.vurunners;

/**
 *
 * @author jordan
 */
public class VURUNNERS {

    public static void main(String[] args) {
       
        String[] names = {
            "Elena", "Thomas", "Hamilton", "Suzie", "Phil", 
            "Matt", "Alex", "Emma", "John", "James", 
            "Jane", "Emily", "Daniel", "Neda", "Aaron", "Kate"
        };
        int[] times = {
            341, 273, 278, 329, 445, 
            402, 388, 275, 243, 334, 
            412, 393, 299, 343, 317, 265
        };

        int firstFastestTime = Integer.MAX_VALUE;
        int secondFastestTime = Integer.MAX_VALUE;
        String firstFastestName = "";
        String secondFastestName = "";

        for (int i = 0; i < names.length; i++) {
            if (times[i] < firstFastestTime) {
                secondFastestTime = firstFastestTime;
                secondFastestName = firstFastestName;
                
                firstFastestTime = times[i];
                firstFastestName = names[i];
            } else if (times[i] < secondFastestTime) {
                secondFastestTime = times[i];
                secondFastestName = names[i];
            }
        }

        System.out.println("Fastest runner: " + firstFastestName + " with time " + firstFastestTime + " minutes.");
        System.out.println("Second fastest runner: " + secondFastestName + " with time " + secondFastestTime + " minutes.");
    }
}
                                                                                                     
